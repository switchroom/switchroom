# switchroom.ai — brand usage rules

Everything in this directory regenerates from `build.py` (+ `wordmark.py`
for the type outlines). Never hand-edit the SVG outputs.

## The mark

A brass patch-bay plate (9-jack grid) with a red patch cable plugged into
the four corner jacks, tracing a sinuous "S". The square icon with the
notched red frame is the **primary mark**.

**Final rendering (owner pick, 2026-07-11): subtle cable, full-depth
board** — `CABLE_DEPTH=1` (red gradient + soft top highlight, no glossy
speculars on the cord) and `BOARD_DEPTH=3` (full-gloss plate: sheen,
inner bevel, top-lit jack bevels with recessed holes, gradient frame).
These are the defaults in `build.py`; favicons stay the flat purpose-built
cuts regardless of depth.

## Color system

| Token | Hex | Use |
|---|---|---|
| charcoal | `#1a1d21` | dark field, mono ink on light |
| bone | `#ece5d8` | mono ink on dark, wordmark on dark |
| brass | `#e8b657` → `#cf9c45` | plate (matte two-stop vertical gradient) |
| brass-flat | `#e0aa4e` | favicon plate (single flat stop) |
| cable red | `#c8302c` (dark `#7c1a17`) | the cord — the only element that is ever red |
| frame red on dark | `#e05550` | notched frame on dark backgrounds only |

Rules:

- **The red notched frame appears only on the full-color standalone icon
  at ≥64px.** Lockups, small sizes, avatars, and circular crops use the
  plate (or disc) alone.
- **Never use the frame in circular contexts** (Telegram, X, maskable
  Android icons) — use `logo-avatar.*`, which keeps everything meaningful
  inside the inner 80% circle.
- **Mono marks:** charcoal ink on light backgrounds, bone on dark. Never a
  mono-red primary mark — only the cord is red, and only in full color.
- **Wordmark is always single color** — charcoal on light, bone on dark.
  The ".ai" never takes brass or red.
- On dark backgrounds the frame lightens to `#e05550`
  (`logo-icon-ondark.svg`).

## Wordmark

Fraunces, wght 560, opsz 20 (lower optical size keeps small settings from
going spindly), SOFT 0, WONK 0, all lowercase: `switchroom.ai`. Pre-outlined
in `wordmark.json` — no live-font dependency downstream.

## Lockups & proportions

- **Horizontal:** plate height = icon unit; gap = 0.375× icon width;
  wordmark x-height optically centered on the plate midline.
- **Stacked:** wordmark width = 1.12× icon width; gap from icon bottom to
  ascender line = 0.5× ascender height.
- **Clear space:** keep ¼ of the icon height clear on all sides of any
  mark or lockup.

## Cuts and what they're for

### Master art (SVG + 1024px PNG preview)

| File | Use |
|---|---|
| `logo-icon.svg/png` | primary mark, light backgrounds, ≥64px |
| `logo-icon-ondark.svg/png` / `logo-icon-dark.png` | primary mark on dark (`-dark.png` = pre-composited on charcoal) |
| `logo-plate.svg/png` | frameless plate — lockups, small sizes <64px, OG |
| `logo-avatar.svg/png` | Telegram / circular avatars, maskable Android icon |
| `logo-avatar-circle-preview.png` | circle-crop preview (what Telegram shows) |
| `logo-horizontal.svg/png`, `logo-horizontal-ondark.svg/png`, `logo-horizontal-dark.png` | horizontal lockup (light / on-dark / pre-composited) |
| `logo-stacked.svg/png`, `logo-stacked-ondark.svg/png`, `logo-stacked-dark.png` | stacked lockup (same variants) |
| `logo-square.svg/png` | framed icon + wordmark, square-ish placements |
| `logo-icon-mono-dark.svg/png` | single-ink charcoal, light backgrounds (print, embossing) |
| `logo-icon-mono-light.svg/png`, `logo-icon-mono-light-darkbg.png` | single-ink bone, dark backgrounds |
| `favicon-16.svg`, `favicon-32.svg` | purpose-built favicon cuts (flat, no frame, no jacks; 32 adds plug dots) |
| `loading-demo.html` | loading motif: cord draws the S via stroke-dashoffset |

### Website /assets drop-ins (raster, final sizes)

| File | Size | Use |
|---|---|---|
| `favicon.ico` | 16+32+48 | legacy `<link rel="icon">` / root favicon |
| `favicon-16.png`, `favicon-32.png` | 16 / 32 | raster favicon fallbacks (flat cuts) |
| `icon-64.png` | 64 | smallest framed-icon size |
| `apple-touch-icon.png` | 180 | iOS home-screen icon |
| `android-chrome-192.png`, `android-chrome-512.png` | 192 / 512 | web-app manifest icons |
| `icon-192.png`, `icon-512.png` | 192 / 512 | generic framed-icon exports |
| `avatar-512.png`, `avatar-640.png` | 512 / 640 | circular avatars (Telegram wants 640) |
| `github-avatar.png` | 512 | GitHub org avatar (bone mono on charcoal) |
| `og-image.png` | 1200×630 | social share card |

### Reference sheets

`contact-sheet.png` (full suite), `depth-comparison.png`,
`board-comparison.png` (rendering-depth studies; final = cable-1 + board-3),
`favicon-16-test.png` / `favicon-32-test.png` (true-size favicon checks).

Sticker/merch: the full-color framed icon is the preferred cut.

## Favicon serving

Serve `favicon-32.svg` as the SVG favicon; a `prefers-color-scheme` swap is
unnecessary because the brass plate holds on both light and dark tabs.
Raster fallbacks: `favicon-16.png`, `favicon-32.png`, and `favicon.ico`
(16+32+48). These stay the flat cuts at every depth setting.

## Distribution

`switchroom-brand-pack.zip` — everything (all SVGs, all PNGs, `favicon.ico`,
this file). `switchroom-logo-svgs.zip` — SVGs only (compat).
